﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.MurenListBox = New System.Windows.Forms.ListBox()
		Me.NietBeschilVlakkListBox = New System.Windows.Forms.ListBox()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.TotalBeschilOppBox = New System.Windows.Forms.TextBox()
		Me.TotalLiterPrimerBox = New System.Windows.Forms.TextBox()
		Me.TotalLiterVerfBox = New System.Windows.Forms.TextBox()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.Label8 = New System.Windows.Forms.Label()
		Me.Button1 = New System.Windows.Forms.Button()
		Me.Button2 = New System.Windows.Forms.Button()
		Me.SuspendLayout()
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Location = New System.Drawing.Point(42, 25)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(30, 13)
		Me.Label1.TabIndex = 0
		Me.Label1.Text = "muur"
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Location = New System.Drawing.Point(368, 25)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(139, 13)
		Me.Label2.TabIndex = 1
		Me.Label2.Text = "Niet beschilderbare vlakken"
		'
		'MurenListBox
		'
		Me.MurenListBox.FormattingEnabled = True
		Me.MurenListBox.Location = New System.Drawing.Point(12, 64)
		Me.MurenListBox.Name = "MurenListBox"
		Me.MurenListBox.Size = New System.Drawing.Size(284, 212)
		Me.MurenListBox.TabIndex = 2
		'
		'NietBeschilVlakkListBox
		'
		Me.NietBeschilVlakkListBox.FormattingEnabled = True
		Me.NietBeschilVlakkListBox.Location = New System.Drawing.Point(347, 64)
		Me.NietBeschilVlakkListBox.Name = "NietBeschilVlakkListBox"
		Me.NietBeschilVlakkListBox.Size = New System.Drawing.Size(284, 212)
		Me.NietBeschilVlakkListBox.TabIndex = 3
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.Location = New System.Drawing.Point(42, 298)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(171, 13)
		Me.Label3.TabIndex = 4
		Me.Label3.Text = "Totaal beschilderbare oppervlakte:"
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.Location = New System.Drawing.Point(42, 323)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(119, 13)
		Me.Label4.TabIndex = 5
		Me.Label4.Text = "Totaal aantal liter primer"
		'
		'Label5
		'
		Me.Label5.AutoSize = True
		Me.Label5.Location = New System.Drawing.Point(42, 352)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(191, 13)
		Me.Label5.TabIndex = 6
		Me.Label5.Text = "Totaal aantal liter muur- en plafondverf:"
		'
		'TotalBeschilOppBox
		'
		Me.TotalBeschilOppBox.Location = New System.Drawing.Point(255, 295)
		Me.TotalBeschilOppBox.Name = "TotalBeschilOppBox"
		Me.TotalBeschilOppBox.Size = New System.Drawing.Size(41, 20)
		Me.TotalBeschilOppBox.TabIndex = 7
		'
		'TotalLiterPrimerBox
		'
		Me.TotalLiterPrimerBox.Location = New System.Drawing.Point(255, 320)
		Me.TotalLiterPrimerBox.Name = "TotalLiterPrimerBox"
		Me.TotalLiterPrimerBox.Size = New System.Drawing.Size(41, 20)
		Me.TotalLiterPrimerBox.TabIndex = 8
		'
		'TotalLiterVerfBox
		'
		Me.TotalLiterVerfBox.Location = New System.Drawing.Point(255, 349)
		Me.TotalLiterVerfBox.Name = "TotalLiterVerfBox"
		Me.TotalLiterVerfBox.Size = New System.Drawing.Size(41, 20)
		Me.TotalLiterVerfBox.TabIndex = 9
		'
		'Label6
		'
		Me.Label6.AutoSize = True
		Me.Label6.Location = New System.Drawing.Point(302, 298)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(18, 13)
		Me.Label6.TabIndex = 10
		Me.Label6.Text = "m²"
		'
		'Label7
		'
		Me.Label7.AutoSize = True
		Me.Label7.Location = New System.Drawing.Point(302, 323)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(9, 13)
		Me.Label7.TabIndex = 11
		Me.Label7.Text = "l"
		'
		'Label8
		'
		Me.Label8.AutoSize = True
		Me.Label8.Location = New System.Drawing.Point(302, 356)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(9, 13)
		Me.Label8.TabIndex = 12
		Me.Label8.Text = "l"
		'
		'Button1
		'
		Me.Button1.Location = New System.Drawing.Point(347, 284)
		Me.Button1.Name = "Button1"
		Me.Button1.Size = New System.Drawing.Size(284, 40)
		Me.Button1.TabIndex = 13
		Me.Button1.Text = "Muur"
		Me.Button1.UseVisualStyleBackColor = True
		'
		'Button2
		'
		Me.Button2.Location = New System.Drawing.Point(347, 330)
		Me.Button2.Name = "Button2"
		Me.Button2.Size = New System.Drawing.Size(284, 39)
		Me.Button2.TabIndex = 14
		Me.Button2.Text = "Niet beschilderbaar vlak"
		Me.Button2.UseVisualStyleBackColor = True
		'
		'Form1
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(643, 538)
		Me.Controls.Add(Me.Button2)
		Me.Controls.Add(Me.Button1)
		Me.Controls.Add(Me.Label8)
		Me.Controls.Add(Me.Label7)
		Me.Controls.Add(Me.Label6)
		Me.Controls.Add(Me.TotalLiterVerfBox)
		Me.Controls.Add(Me.TotalLiterPrimerBox)
		Me.Controls.Add(Me.TotalBeschilOppBox)
		Me.Controls.Add(Me.Label5)
		Me.Controls.Add(Me.Label4)
		Me.Controls.Add(Me.Label3)
		Me.Controls.Add(Me.NietBeschilVlakkListBox)
		Me.Controls.Add(Me.MurenListBox)
		Me.Controls.Add(Me.Label2)
		Me.Controls.Add(Me.Label1)
		Me.Name = "Form1"
		Me.Text = "Form1"
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents Label1 As Label
	Friend WithEvents Label2 As Label
	Friend WithEvents MurenListBox As ListBox
	Friend WithEvents NietBeschilVlakkListBox As ListBox
	Friend WithEvents Label3 As Label
	Friend WithEvents Label4 As Label
	Friend WithEvents Label5 As Label
	Friend WithEvents TotalBeschilOppBox As TextBox
	Friend WithEvents TotalLiterPrimerBox As TextBox
	Friend WithEvents TotalLiterVerfBox As TextBox
	Friend WithEvents Label6 As Label
	Friend WithEvents Label7 As Label
	Friend WithEvents Label8 As Label
	Friend WithEvents Button1 As Button
	Friend WithEvents Button2 As Button
End Class
