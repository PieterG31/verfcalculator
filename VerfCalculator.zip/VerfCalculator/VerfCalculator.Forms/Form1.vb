﻿Imports VerfCalculator.domain

Public Class Form1
	Public dc As DomainController


	Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
		Try
			Dim hoogte As Double = InputBox("Geef een hoogte in", "VerfCalculator")
			Dim breedte As Double = InputBox("Geef een breedte in", "VerfCalculator")
			Dim naam As String = InputBox("Geef een naam in", "VerfCalculator")

			'dc.addMuur(hoogte, breedte, naam)

			'MurenListBox.Items.Add(dc.getMuren().First.ToString())
			'MurenListBox.Items.Add(dc.getMuren().ToString())

			'For i As Integer = 0 To dc.getMuren().Count - 1
			MurenListBox.Items.Add("test")

			'Next


			MurenListBox.Items.Add("test")
			MurenListBox.Items.Add("test2")


		Catch ex As Exception

		End Try




	End Sub

End Class