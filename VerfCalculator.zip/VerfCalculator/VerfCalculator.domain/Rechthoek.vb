﻿Public Class Rechthoek
	Private _breedte As Double
	Private _hoogte As Double

	Public Property Breedte As Double
		Get
			Return _breedte
		End Get
		Set(value As Double)
			value = _breedte
		End Set
	End Property

	Public Property Hoogte As Double
		Get
			Return _hoogte
		End Get
		Set(value As Double)
			value = _hoogte
		End Set
	End Property

	Public Function getOppervlakte() As Double
		Return _breedte * _hoogte
	End Function

	Public Sub New()

	End Sub

	Public Sub New(Breedte As Double, Hoogte As Double)
		Me.breedte = Breedte
		Me.breedte = Hoogte
	End Sub

	Public Overrides Function ToString() As String
		Return _breedte & "m x " & _hoogte & "m"
	End Function


End Class
