﻿Public Class Kamer
	Private _muren As List(Of Muur)


	Public ReadOnly Property Muren As List(Of Muur)
		Get
			Return New List(Of Muur)(_muren)
		End Get
	End Property

	Friend Sub addMuur(muur As Muur)
		_muren.Add(muur)
	End Sub
	'begrijp ik niet echt
	Friend Sub addNietBeschilderbaarVlak(muur As Muur, rechthoek As Rechthoek)
		muur.addNietBeschilderbaarVlak(rechthoek)
	End Sub

	Public Function getBeschilderbareOppervlakte() As Double
		Dim totaalMuren As Double
		For i As Integer = 0 To _muren.Count - 1

			totaalMuren += _muren(i).getBeschilderbareOppervlakte

		Next

		Return totaalMuren
	End Function

End Class
