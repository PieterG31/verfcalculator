﻿Public Class Product

	Private _aantalLagen As Integer
	Private _naam As String
	Private _rendement As Integer

	Public Property AantalLagen As Integer
		Get
			Return _aantalLagen
		End Get
		Set(value As Integer)
			value = _aantalLagen
		End Set


	End Property

	Public Property Naam As String
		Get
			Return _naam
		End Get
		Set(value As String)
			value = _naam
		End Set
	End Property

	Public Property Rendement As Integer
		Get
			Return _rendement
		End Get
		Set(value As Integer)
			value = _rendement
		End Set
	End Property

	Public Function getAantalLiter(aantalVierkanteMeter As Double) As Double
		Return aantalVierkanteMeter * _aantalLagen / _rendement
	End Function







End Class
