﻿Public Class Muur
	Private _afmetingen As Rechthoek
	Private _naam As String
	Private _nietBeschilderbareVlakken As List(Of Rechthoek)

	Public Property Afmetingen As Rechthoek
		Get
			Return _afmetingen
		End Get
		Set(value As Rechthoek)
			value = _afmetingen
		End Set
	End Property

	Public Property Naam As String
		Get
			Return _naam
		End Get
		Set(value As String)
			value = _naam
		End Set
	End Property
	Public ReadOnly Property NietBeschilderBareVlakken As List(Of Rechthoek)
		Get
			Return New List(Of Rechthoek)(_nietBeschilderbareVlakken)
		End Get

	End Property

	Friend Sub addNietBeschilderbaarVlak(vlak As Rechthoek)
		_nietBeschilderbareVlakken.Add(vlak)
	End Sub
	Public Function getBeschilderbareOppervlakte() As Double

		Dim TotaleOppervlakte As Double = _afmetingen.getOppervlakte()

		Dim SomNietBeschilderbareVlakken As Double
		For i As Integer = 0 To _nietBeschilderbareVlakken.Count - 1
			SomNietBeschilderbareVlakken += _nietBeschilderbareVlakken(i).getOppervlakte()
		Next

		Return TotaleOppervlakte - SomNietBeschilderbareVlakken


	End Function
	Friend Sub New()

	End Sub

	Friend Sub New(breedte As Double, hoogte As Double, naam As String)
		Me.Naam = naam
		_afmetingen.Breedte = breedte
		_afmetingen.Hoogte = hoogte
	End Sub

	Public Overrides Function ToString() As String
		Afmetingen.ToString()
	End Function
End Class
