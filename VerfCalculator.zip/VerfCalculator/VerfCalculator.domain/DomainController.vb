﻿Public Class DomainController
	Private _kamer As Kamer
	Private _primer As Product
	Private _verf As Product






	Public Sub addMuur(hoogte As Double, breedte As Double, naam As String)

		_kamer.addMuur(New Muur(breedte, hoogte, naam))

	End Sub

	Public Function getAantalLiterPrimer() As Double
		Return _primer.getAantalLiter(_kamer.getBeschilderbareOppervlakte())
	End Function

	Public Function getAantalLiterVerf() As Double
		Return _verf.getAantalLiter(_kamer.getBeschilderbareOppervlakte())
	End Function

	Public Function getBeschilderbareOppervlakte() As Double
		Return _kamer.getBeschilderbareOppervlakte()
	End Function

	Public Function getMuren() As List(Of Muur)
		Return _kamer.Muren
	End Function

	Public Sub setPrimer(rendement As Integer, naam As String, aantalLagen As Integer)
		_primer.Rendement = rendement
		_primer.Naam = naam
		_primer.AantalLagen = aantalLagen
	End Sub
	Public Sub setVerf(rendement As Integer, naam As String, aantalLagen As Integer)
		_verf.Rendement = rendement
		_verf.Naam = naam
		_verf.AantalLagen = aantalLagen
	End Sub


End Class
